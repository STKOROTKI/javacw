package dsbook;

import javax.persistence.*;

@Entity
public class Comment {

        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private int id;
        private String commentText;
        @ManyToOne
        private Book bokcomments;

        public Comment(String commentText, Book bokcomments) {
            this.commentText = commentText;
            this.bokcomments = bokcomments;
        }

        public Comment() {

        }

        @Override
        public String toString() {
            return this.commentText;
        }
    }

