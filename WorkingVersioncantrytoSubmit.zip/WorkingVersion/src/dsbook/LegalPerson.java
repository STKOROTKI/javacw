package dsbook;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;

@Entity
@Setter
@Getter
@NoArgsConstructor
public class LegalPerson extends User{
    private String CompanyName;
    private String compaddres;
    private String representative;
    private String compphone;

    public LegalPerson(int userId, String login, String password, UserType userType, String usermail, String userpostalcode, String userphonenumber, String companyName, String compaddres, String representative, String compphone) {
        super(userId, login, password, userType, usermail, userpostalcode, userphonenumber);
        CompanyName = companyName;
        this.compaddres = compaddres;
        this.representative = representative;
        this.compphone = compphone;
    }

    public LegalPerson(UserType userType, String login, String password, String usermail, String userpostalcode, String userphonenumber, String companyName, String compaddres, String representative, String compphone) {
        super(userType, login, password, usermail, userpostalcode, userphonenumber);
        CompanyName = companyName;
        this.compaddres = compaddres;
        this.representative = representative;
        this.compphone = compphone;
    }

}
