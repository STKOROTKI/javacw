package dsbook;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Entity;
import java.time.LocalDate;

@Entity
@Getter
@Setter
@NoArgsConstructor

public class Individual extends User{
    private String individname;
    private String individsurname;
    private LocalDate birthdate;

    public Individual(int userId, String login, String password, UserType userType,  String usermail, String userpostalcode, String userphonenumber, String individname, String individsurname, LocalDate birthdate) {
        super(userId, login, password, userType, usermail, userpostalcode, userphonenumber);
        this.individname = individname;
        this.individsurname = individsurname;
        this.birthdate = birthdate;
    }

    public Individual(UserType userType,  String login, String password, String usermail, String userpostalcode, String userphonenumber, String individname, String individsurname/*, LocalDate birthdate*/) {
        super(userType, login, password, usermail, userpostalcode, userphonenumber);
        this.individname = individname;
        this.individsurname = individsurname;
    //    this.birthdate = birthdate;
    }




}
