package dsbook;

public enum UserType {
    Administrator, Customer, Employee;
}
