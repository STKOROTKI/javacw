package dsbook;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;

import javax.persistence.*;
import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@Entity
@NoArgsConstructor


public class Book {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    private String bookTitle;
    private LocalDate publishDate;
    private int pageNum;
    private String authors;
    private int edition;
    private String description;
    private Genre genre;


    @OneToMany(mappedBy = "bokcomments", cascade = {CascadeType.ALL}, orphanRemoval = true)
    @OrderBy("id ASC")
    @LazyCollection(LazyCollectionOption.FALSE)
    private List<Comment> comment;


    public Book(String bookTitle, LocalDate publishDate, int pageNum, String authors, int edition, String description, Genre genre) {
        this.bookTitle = bookTitle;
        this.publishDate = publishDate;
        this.pageNum = pageNum;
        this.authors = authors;
        this.edition = edition;
        this.description = description;
        this.genre = genre;
    }

    public Book(int id, String bookTitle, LocalDate publishDate, int pageNum, String authors, int edition, String description, Genre genre) {
        this.id = id;
        this.bookTitle = bookTitle;
        this.publishDate = publishDate;
        this.pageNum = pageNum;
        this.authors = authors;
        this.edition = edition;
        this.description = description;
        this.genre = genre;
    }

    @Override
    public String toString() {
        return "Book{" +
                "id=" + id +
                ", bookTitle='" + bookTitle + '\'' +
                ", publishDate=" + publishDate +
                ", pageNum=" + pageNum +
                ", authors='" + authors + '\'' +
                ", edition=" + edition +
                ", description='" + description + '\'' +
                ", genre=" + genre +
                '}';
    }


}
