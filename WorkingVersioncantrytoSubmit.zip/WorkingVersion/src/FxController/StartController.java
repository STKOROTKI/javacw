package FxController;

import HibernateControllers.UserHibernate;
import dsbook.User;
import javafx.application.Application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.io.IOException;

import static utils.JavaFxUtils.alertMessage;

public class StartController extends Application {
    @FXML
    public TextField Loginfield;
    @FXML
    public PasswordField passwordField;

    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("BookShop");
    UserHibernate userController = new UserHibernate(entityManagerFactory);
    //Ccommentcontroller ccommentcontroller =new Ccommentcontroller(entityManagerFactory);

    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(StartController.class.getResource("/demo/Start.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        stage.setTitle("Book Shop");
        stage.setScene(scene);
        stage.show();    }

    public static void main(String[] args) {
        launch();
    }

    public void Validateandlogin() throws IOException {

        User user = userController.getUser(Loginfield.getText(), passwordField.getText());
        if (user != null) {
            System.out.println(Loginfield.getText() + " " + passwordField.getText());
            FXMLLoader fxmlLoader = new FXMLLoader(StartController.class.getResource("/demo/MainWindow.fxml"));
            Parent parent = fxmlLoader.load();
            Scene scene = new Scene(parent);
            MainWindow mainWindowController = fxmlLoader.getController();
            mainWindowController.setUserID(user.getUserId());
            Stage stage = (Stage) Loginfield.getScene().getWindow();


            stage.setTitle("Book Shop");
            stage.setScene(scene);
            stage.show();

        }
        else {
            alertMessage("User doesn't exist","sorry");
        }

    }
    public void Loadsignupform (ActionEvent actionEvent) throws IOException{

        FXMLLoader fxmlLoader = new FXMLLoader(StartController.class.getResource("../demo/sign-up-page.fxml"));
        Scene scene = new Scene(fxmlLoader.load());
        Stage stage = (Stage) Loginfield.getScene().getWindow();
        stage.setTitle("Sign up");
        stage.setScene(scene);
        stage.show();




        
    }
}
