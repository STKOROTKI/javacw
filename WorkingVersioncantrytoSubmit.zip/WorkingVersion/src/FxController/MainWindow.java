package FxController;


import HibernateControllers.BookHibernate;
import HibernateControllers.CommentHibernate;
import HibernateControllers.UserHibernate;
import dsbook.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import java.io.IOException;
import java.net.URL;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;


import static utils.JavaFxUtils.alertMessage;

public class MainWindow implements Initializable {
    @FXML
    public Tab Admin;
    @FXML
    public Tab managebooks;
    @FXML

    public Button addbookfx;
    public Button removebookfx;

    public TextField changeid;
    public Button usersupdate;
    public TextField changepsw;
    public TextField changenickname;
    public TextField changesurname;
    public TextField changename;
    public TextField changemail;
    public Button removeuser;
    public TextField idusers;
    public ComboBox roleinadminfield;
    public TextField adminfieldpostnumber;
    public TextField phonefielddddd;
    public TextField commmtitle;
    public TextField commmaddreeesss;
    public TextField coooommmmrepres;
    public ListView orderbooklist;
    public Button searchbookfxxx;
    public Button removefxid;
    public TextField idtodelete;
    public MenuItem comment;
    public Button userinf;
    public TextField searcheditionfx;
    private int privateuserid;
    @FXML
    public ListView bookList;
    @FXML
    public ListView commentsBook;
    @FXML
    public ListView shopBookList;
    @FXML
    public TextField searchTitle;
    @FXML
    public DatePicker searchPublish;
    @FXML
    public TextField searchAuthor;
    @FXML
    public ComboBox searchGenre;
    @FXML
    public TextField bookTitle;
    @FXML
    public TextArea bookDesc;
    @FXML
    public DatePicker pubDate;
    @FXML
    public TextField pgNum;
    @FXML
    public TextField edition;
    @FXML
    public ComboBox genre;
    @FXML
    public TextArea authors;

    @FXML
    public MenuItem viewInfoItem;
    @FXML
    public TextArea bookInfoField;
    @FXML
    public TreeView orderList;

    public String stringgenre;
    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("BookShop");
    UserHibernate userController = new UserHibernate(entityManagerFactory);
    BookHibernate bookController = new BookHibernate(entityManagerFactory);
    CommentHibernate commentHibernate=new CommentHibernate(entityManagerFactory);









    public void addBook(ActionEvent event) throws SQLException {

        Book book = new Book(bookTitle.getText(),pubDate.getValue(),Integer.parseInt(pgNum.getText()),authors.getText(),Integer.parseInt(edition.getText()),bookDesc.getText(), Genre.valueOf(genre.getSelectionModel().getSelectedItem().toString()));
        bookController.createBook(book);
        refreshBooks();
    }

    public void refreshBooks() {
        List<Book> allAvailableBooks = bookController.getAllAvailableBooks(false);
        shopBookList.getItems().clear();
        allAvailableBooks.forEach(book -> shopBookList.getItems().add(book.getId() + ":" + book.getBookTitle()));

        bookTitle.clear();
        authors.clear();
        edition.clear();
        pubDate.getEditor().clear();

    }
    public void removebook (ActionEvent actionEvent) {
        String boId = shopBookList.getSelectionModel().getSelectedItem().toString().split(":")[0];
        bookController.removeBook(Integer.parseInt(boId));
        refreshBooks();
    }
//    public void searchbook() {
//        List<Book> filteredBooks = bookController.getFilteredBooks(searchTitle.getText(), searchAuthor.getText(), searchPublish.getValue(),  Genre.valueOf(searchGenre.getSelectionModel().getSelectedItem().toString()));
//
//    }

    public void viewInfoMenuButton() throws IOException
    {
        String bookId = shopBookList.getSelectionModel().getSelectedItem().toString().split(":")[0];
        Book book = bookController.getBookById(Integer.parseInt(bookId));
        alertMessage("Book Info:",book.toString());
    }
    @Override
    public void initialize(URL location, ResourceBundle resources) {
        genre.getItems().addAll(Genre.values());
        searchGenre.getItems().addAll(Genre.values());

        roleinadminfield.getItems().addAll(UserType.Administrator, UserType.Customer, UserType.Employee);
        refreshBooks();
    }












    //users modifications






public void setUserID(int privateuserid)
{
    this.privateuserid = privateuserid;
    changeAccessLevel();
}

    public void changeAccessLevel()
    {

        User user = userController.getUserById(privateuserid);
        System.out.println(privateuserid);
        System.out.println(user.toString());
        if(user.getUserType() == UserType.Customer)
        {
            Admin.setDisable(true);
            addbookfx.setDisable(true);
            removebookfx.setDisable(true);

        } else if (user.getUserType() == UserType.Employee)
        {
            Admin.setDisable(true);
        }
    }

    public void update(ActionEvent event)
    {
        LegalPerson company = new LegalPerson(UserType.valueOf(roleinadminfield.getSelectionModel().getSelectedItem().toString()), changenickname.getText(), changepsw.getText(), changemail.getText(),
                adminfieldpostnumber.getText(), phonefielddddd.getText(), commmtitle.getText(), commmaddreeesss.getText(), coooommmmrepres.getText(), phonefielddddd.getText());
        userController.createUser(company);
    }





    public void roleinadminfieldfxxxx(ActionEvent event) {

    }



    public void userinfshow(ActionEvent event) {

      User user = userController.getUserById(privateuserid);
      alertMessage("user Info:",user.toString());
    }



    public void comentbook(ActionEvent event) throws IOException {//це хуйня

        FXMLLoader fxmlLoader = new FXMLLoader(MainWindow.class.getResource("../demo/ccomment.fxml"));

        Scene scene =new Scene(fxmlLoader.load());
        Stage stage = new Stage();
        stage.setTitle("Comment");
        stage.setScene(scene);
        stage.show();





    }

    public void findbook(ActionEvent event) {


        String genre;

        if (searchGenre.getSelectionModel().getSelectedItem() == null)
        {
            genre = "";
        }
        else
        {
            genre = searchGenre.getSelectionModel().getSelectedItem().toString();
        }

        List<Book> filteredBooks = bookController.filteredBooks(searchTitle.getText(),Integer.parseInt(searcheditionfx.getText()),searchAuthor.getText(), genre);

        bookList.getItems().clear();
        filteredBooks.forEach(b -> bookList.getItems().add(b.getId() + ":" + b.getBookTitle()));
    }
}
