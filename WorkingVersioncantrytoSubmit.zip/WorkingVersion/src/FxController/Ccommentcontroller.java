package FxController;

import HibernateControllers.BookHibernate;
import HibernateControllers.UserHibernate;
import dsbook.Book;

import dsbook.Comment;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;


import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import java.io.IOException;
import java.net.URL;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;

import static utils.JavaFxUtils.alertMessage;

public class Ccommentcontroller implements Initializable {







    public TextField commentfield;
    public Button savecomfx;
    public ListView bookList;
    private int idb;

    EntityManagerFactory entityManagerFactory = Persistence.createEntityManagerFactory("BookShop");
    BookHibernate bookHibernate = new BookHibernate(entityManagerFactory);

    public void savecomment(ActionEvent event) {

        int id = Integer.parseInt(bookList.getSelectionModel().getSelectedItem().toString().split(":")[0]);
        Book book = bookHibernate.getBookById(id);

            System.out.println("Your name: " + commentfield.getText());
            Comment bokComment = new Comment(commentfield.getText(), book);
            book.getComment().add(bokComment);
        bookHibernate.updateBook(book);

        alertMessage("User created successfully.","gg");
    }


    public void refreshBooks() {
        List<Book> allAvailableBooks = bookHibernate.getAllAvailableBooks(false);
        bookList.getItems().clear();
        allAvailableBooks.forEach(book -> bookList.getItems().add(book.getId() + ":" + book.getBookTitle()));

//        bookTitle.clear();
//        authors.clear();
//        edition.clear();
//        pubDate.getEditor().clear();

    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        refreshBooks();
    }





}
