package HibernateControllers;

import dsbook.Book;
import dsbook.Genre;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class BookHibernate {

    private EntityManagerFactory emf = null;

    public BookHibernate(EntityManagerFactory emf) {
        this.emf = emf;
    }



    private EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void createBook(Book book) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(book);
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }
//    public List<Book> filteredBooks(String title, int edition, String author,  String stringgenre)
//    {
//        EntityManager em = getEntityManager();
//        try {
//            CriteriaBuilder cb = em.getCriteriaBuilder();
//            CriteriaQuery<Book> query = cb.createQuery(Book.class);
//            Root<Book> root = query.from(Book.class);
//            query.select(root).where(cb.and(cb.like(root.get("bookTitle"), "%" + title + "%")), cb.like(root.get("authors"), "%" + author + "%"), cb.equal(root.get("edition"), edition));
//
//            Query q = em.createQuery(query);
//            return q.getResultList();
//        } catch (Exception e)
//        {
//            e.printStackTrace();
//        } finally
//        {
//            if (em != null)
//            {
//                em.close();
//            }
//        }
//        return null;
//    }
    public void updateBook(Book book) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.merge(book);
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public Book getBookById(int id) {
        EntityManager em = null;
        Book book = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            book = em.getReference(Book.class, id);
            em.getTransaction().commit();
        } catch (Exception e) {
            System.out.println("No such user by given Id");
        }
        return book;
    }

    public void removeBook(int id) {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Book book = null;
            try {
                book = em.getReference(Book.class, id);
                book.getId();
            } catch (Exception e) {
                System.out.println("No such book by given Id");
            }
            em.remove(book);
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Book> getAllAvailableBooks(boolean isAvailable) {
        EntityManager em = emf.createEntityManager();
        try {
            CriteriaBuilder criteriaBuilder = em.getCriteriaBuilder();
            CriteriaQuery<Book> query = criteriaBuilder.createQuery(Book.class);
            Root<Book> root = query.from(Book.class);
            if (isAvailable)
                query.select(root).where(criteriaBuilder.equal(root.get("available"), true));
            Query q = em.createQuery(query);
            return q.getResultList();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (em != null) {
                em.close();
            }
        }
        return new ArrayList<>();
    }

//    public List<Book> getFilteredBooks(String bookTitle, String authors, LocalDate publishDateStart, Genre genre) {
//
//        EntityManager em = getEntityManager();
//        try {
//            CriteriaBuilder cb = em.getCriteriaBuilder();
//            CriteriaQuery<Book> query = cb.createQuery(Book.class);
//            Root<Book> root = query.from(Book.class);
//            query.select(root).where(cb.and(cb.like(root.get("bookTitle"), "%" + bookTitle + "%")), cb.like(root.get("authors"), "%" + authors + "%"),  cb.like(root.get("genre"), "%" + genre + "%"));
//            Query q = em.createQuery(query);
//            return q.getResultList();
//        } catch (Exception e) {
//            e.printStackTrace();
//        } finally {
//            if (em != null) {
//                em.close();
//            }
//        }
//        return null;
//    }

    public List<Book> filteredBooks(String title, int edition, String author, String searchGenre) {
        EntityManager em = getEntityManager();
        try {
            CriteriaBuilder cb = em.getCriteriaBuilder();
            CriteriaQuery<Book> query = cb.createQuery(Book.class);
            Root<Book> root = query.from(Book.class);
            query.select(root).where(cb.and(cb.like(root.get("bookTitle"), "%" + title + "%")), cb.like(root.get("authors"), "%" + author + "%"), cb.equal(root.get("edition"), edition));

            Query q = em.createQuery(query);
            return q.getResultList();
        } catch (Exception e)
        {
            e.printStackTrace();
        } finally
        {
            if (em != null)
            {
                em.close();
            }
        }
        return null;
    }
}



